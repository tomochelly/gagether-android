GAGETHER Sites v307 전체 소스 — 비공개 다운로드

기준 커밋: 651abafcf4978c4dd8c8a1706ab8db7cb39ce87b
Sites 버전: appgprj_6ad1ef24b5c08191a367cd141de63a3a~appgver_0dec98900c7c8191a179a74739cfff57
기존 배포 ID: appgdep_6ae5c644e9ec8191a3a02c207de8a0f1
Sites의 저장 버전 조회 결과에서 v307과 위 커밋의 일치를 확인했습니다.
원본 저장소, Sites 배포, GitHub를 변경하지 않았습니다. 이 자료를 공개 GitHub에 올리지 마세요.

1. 다운로드와 복원
소스 ZIP 6개를 모두 받아 같은 새 빈 폴더에 풀면 하나의 web/ 디렉터리로 합쳐집니다.
각 ZIP은 독립된 일반 ZIP입니다. 분할 ZIP(.z01)처럼 이어 붙이지 마세요.
기존 GitHub checkout이나 이전 overlay 위에 덮어쓰지 말고 새 폴더를 사용하세요.
이 6개에는 이전 overlay에서 필요한 비공개 입력도 들어 있어 overlay를 다시 덮어쓸 필요가 없습니다.

소스 파일: 12,838개
소스 원본 합계: 5,253,064,632바이트 (5.253 GB, 4.892 GiB)
소스 ZIP 합계: 4,680,230,404바이트 (4.680 GB)

gagether-v307-source-01-of-06.zip
  압축 크기: 737,608,707바이트 / 소스 6,428개 / 원본 938,254,943바이트
  SHA-256: 9979a6c390a01e70bbe555ee2da3ed6e7035cb239d5abae868b284f53ecb4933
gagether-v307-source-02-of-06.zip
  압축 크기: 879,543,469바이트 / 소스 1,024개 / 원본 942,696,836바이트
  SHA-256: 6fd696d42f46dc535e9e7df3cf6b40e60d3af66a5a7d5df76e294e51ef0ab25d
gagether-v307-source-03-of-06.zip
  압축 크기: 850,595,072바이트 / 소스 504개 / 원본 942,953,390바이트
  SHA-256: 7682254975b120b60f557c21af8e1f6a69baf900474597eec3246188fc09d6a8
gagether-v307-source-04-of-06.zip
  압축 크기: 859,419,741바이트 / 소스 511개 / 원본 942,114,978바이트
  SHA-256: 03b14c034413f80d4ac60d7f1477988735d0de77e849deb002163b5b8facded8
gagether-v307-source-05-of-06.zip
  압축 크기: 851,007,853바이트 / 소스 479개 / 원본 942,250,827바이트
  SHA-256: cd62e191d1c345e32218cd31f6e825b7cbb88afecff901735eecd1a5b198e83c
gagether-v307-source-06-of-06.zip
  압축 크기: 502,055,562바이트 / 소스 3,892개 / 원본 544,793,658바이트
  SHA-256: d62b9c13f421dce92cee1e97b7c2fe289bda6f80a470f042524207770f333d4d

2. 포함 범위와 제외
Git 커밋에 있는 총 12,840개 파일(5,253,715,498바이트)을 전부 조사했습니다.
Git blob을 직접 읽었으며 현재 작업 폴더의 수정 내용, Git 줄바꿈 변환, export-ignore 필터를 적용하지 않았습니다.
이미지·음성·영상 원본, 연구/테스트/검증 입력, 스크립트, 잠금 파일, 소스에 포함된 Sites 설정을 보존합니다.
실행 권한도 ZIP 메타데이터와 manifest의 Git mode에 기록했습니다. Git LFS 포인터와 submodule은 없습니다.
node_modules, dist, .next, .vinext, .wrangler, .sites-runtime, 환경/시크릿 파일, 개인 키는 내보내기에 넣지 않았습니다.
사용자 제외 조건에 해당하며 이 커밋에 실제 존재했던 파일은 다음 2개입니다:
  discord/.env.example — 239바이트 — 환경 파일(.env 계열은 예제도 제외)
  tsconfig.tsbuildinfo — 650,627바이트 — TypeScript 빌드 캐시
build/는 실행 소스와 Vite 플러그인이 있으므로 포함했습니다. 빌드 결과물 dist/와는 별개입니다.
환경 변수 값이나 개인 키를 다른 위치에서 추가 수집하지 않았습니다.
소스 텍스트와 522개 압축 내부 항목에 정해진 자격증명/개인 키 패턴 검사를 수행했으며 포함 파일의 검출은 0개입니다.
D1 운영 덤프, R2 운영 백업, 저장소 이력(.git), 로컬 작업/배포 아카이브는 이 소스 묶음의 대상이 아닙니다.

3. 도감 데이터 복원 및 실행 준비
content/character-rosters/bootstrap.json은 원래 커밋에 직접 들어 있지 않습니다.
대신 커밋에 포함된 recovery/*.b64 179개가 정확한 원본입니다. 새 web/ 폴더에서 다음을 실행하세요:
  node ops/restore-roster-snapshot.mjs
복원 결과 36,933,668바이트, SHA-256 ec29021ad01832da2ac48335f1bda58bed04befa11f774cde7a6b91e0f4eb60a
복원 조각, 압축 내용, 복원 결과의 고정 해시 일치를 실제로 검증했습니다. build/dev도 이 복원을 먼저 실행합니다.
package.json 기준 Node.js >=22.13.0, pnpm 11.25.0입니다. CI의 Node 버전은 24입니다.
node_modules는 제외했으므로 새 환경에서는 잠금 파일에 맞춰 의존성을 설치해야 합니다.
테스트 실행 전 위 도감 복원을 먼저 수행하세요. 데이터·환경 설정은 이전 운영 백업/인수인계 자료를 별도로 사용하세요.
Sites 전용 런타임 의존성은 원본 그대로이며 Cloudflare 이전을 위한 코드 수정은 하지 않았습니다.

4. 이전 전달본과 비교
공개 GitHub 기준: tomochelly/gagether-android, d4c8108374c618f5156c93e4f596529be5bdc47b의 web/
공개 Git tree: 799a62a71a789a818e5eb1070a446607830da1a1 (전체 조회, truncated=false)
비공개 overlay: gagether-private-source-overlay.zip
overlay 크기: 28,927,885바이트 / SHA-256 a0aa2909dcecff0a1e68892b5eddd2b0280cc22477f485f71e88c69e55244042
두 전달본 모두에 경로가 없던 파일: 10,890개, 5,182,439,409바이트
목록: missing-from-github-and-overlay.csv (경로, 크기, SHA-256, 해당 ZIP)
이전 별도 validation-inputs ZIP에만 있었던 5개는 위 비교 기준에는 없으므로 목록에 포함하되 inPriorValidationZip=true로 표시했습니다.
경로가 있었지만 바이트가 달랐던 1,516개도 different-from-previous-export.csv에 별도로 기록했습니다.
그중 1,483개는 줄바꿈만 다르고, 33개는 내용이 다릅니다.
이번 파일은 최신 GitHub 내용을 섞지 않고 지정된 v307 Git 커밋을 그대로 보존합니다.
10MB 초과 파일: 20개. 기준은 엄격히 10,000,000바이트 초과입니다.
목록: files-over-10MB.csv

5. 전체 목록과 검증
source-manifest.json — 전체 파일 경로·바이트 수·SHA-256·Git blob SHA-1·권한·ZIP 위치·이전 전달 여부
all-files.csv — 읽기 쉬운 전체 파일 목록
source-files.sha256 — 전체 파일의 표준 SHA-256 체크섬 목록(web/ 경로)
excluded-files.csv — 제외한 커밋 파일과 사유
export-summary.json — 총계, 각 ZIP 크기·해시, Sites/GitHub 기준
verification.json — ZIP CRC·파일 SHA-256·Git blob·실행 권한·별도 복사본 검증 결과
input-validation.json — 도감 복원, 7개 이미지/원본 검사, 기존 테스트 입력 5개 해시 검사 결과
압축 파일 6개와 12,838개 파일의 전수 검증을 통과했습니다. 이미지 원본 검사 7개와 도감 복원도 통과했습니다.
새 환경 의존성 설치: 미확인(실행하지 않음). 전체 빌드: 미확인(실행하지 않음). 전체 테스트 스위트: 미확인(실행하지 않음).
검증 스크립트는 읽기 전용이며, ZIP 6개와 보고서 파일들을 같은 폴더에 둔 뒤 실행합니다:
  python verify-export.py
압축을 푼 web/ 폴더까지 대조하려면:
  python verify-export.py --source-root "압축을 푼 폴더/web"

gagether-v307-export-reports.zip에는 이 안내와 전체 manifest/CSV/검증 자료가 들어 있습니다. 소스 ZIP 6개는 별도로 필요합니다.
archive-checksums.sha256에는 소스 ZIP 6개와 보고서 ZIP의 크기 대조용 해시가 기록됩니다.
