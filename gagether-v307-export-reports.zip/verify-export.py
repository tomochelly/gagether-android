"""Read-only verifier for the GAGETHER v307 private source export (Python 3.9+)."""
import argparse, hashlib, json, pathlib, zipfile

def digest_file(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--directory',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent)
    ap.add_argument('--source-root',type=pathlib.Path,help='Optional extracted web directory; validates it without changing it.')
    args=ap.parse_args();root=args.directory
    manifest=json.loads((root/'source-manifest.json').read_text(encoding='utf-8'))
    summary=json.loads((root/'export-summary.json').read_text(encoding='utf-8'))
    expected={r['archivePath']:r for r in manifest['files']}
    assert len(expected)==manifest['fileCount'],'Duplicate manifest paths'
    seen=set();total=0;verified=[]
    for part in summary['archives']:
        path=root/part['file']
        assert path.stat().st_size==part['bytes'],f'Archive size: {path.name}'
        assert digest_file(path)==part['sha256'],f'Archive SHA-256: {path.name}'
        n=0;size=0
        with zipfile.ZipFile(path) as z:
            for info in z.infolist():
                assert info.filename in expected,f'Unexpected entry: {info.filename}'
                assert info.filename not in seen,f'Duplicate entry: {info.filename}'
                row=expected[info.filename]
                assert row['archive']==part['file'],'Archive assignment mismatch'
                assert info.file_size==row['bytes'],f'File size: {info.filename}'
                h=hashlib.sha256();git=hashlib.sha1(b'blob '+str(info.file_size).encode()+b'\0')
                with z.open(info) as f:
                    for b in iter(lambda:f.read(1024*1024),b''):h.update(b);git.update(b)
                assert h.hexdigest()==row['sha256'],f'File SHA-256: {info.filename}'
                assert git.hexdigest()==row['gitBlob'],f'Git blob: {info.filename}'
                assert ((info.external_attr>>16)&0o777)==(int(row['mode'],8)&0o777),'File mode mismatch'
                if args.source_root:
                    local=args.source_root/row['path']
                    assert local.is_file() and local.stat().st_size==row['bytes'],f'Extracted file size: {row["path"]}'
                    assert digest_file(local)==row['sha256'],f'Extracted SHA-256: {row["path"]}'
                seen.add(info.filename);n+=1;size+=info.file_size
        assert n==part['sourceFiles'] and size==part['uncompressedBytes'],'Part totals mismatch'
        verified.append({'file':part['file'],'files':n,'uncompressedBytes':size,'sha256':part['sha256']});total+=size
    assert seen==set(expected),'Missing files'
    assert total==manifest['totalBytes']==summary['exportedBytes'],'Byte totals mismatch'
    print(json.dumps({'passed':True,'sourceCommit':manifest['sourceCommit'],'verifiedFiles':len(seen),'verifiedBytes':total,'archives':verified,'zipCrcChecked':True,'fileSha256Checked':True,'gitBlobSha1Checked':True,'fileModesChecked':True,'extractedSourceChecked':bool(args.source_root)},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
